import re
import time
import sys
from logger import Logger as logger
from ciscoApi import Cisco as cisco
import logging
import csv
import yaml

logging.basicConfig(level=logging.DEBUG)

# load config file for use globally
with open('config.yml', 'r') as cf:
    config = yaml.safe_load(cf)

def readInputMacs():
    ''' Returns a list of MAC addresses to be traced from inputfile '''
    column_name = 'Mac Addresses'
    mac_list = []
    mac_count = 0
    inputFile = config['settings']['input_file_name']

    logger.logAndPrint(f'Mac import from file is enabled, importing from .csv {inputFile}.', 1)
    try:
        with open(inputFile, newline='') as inFile:
            # Create a CSV reader object
            reader = csv.DictReader(inFile)
            for row in reader:
                m = row[column_name]
                if ',' in m:
                    print('Splitting '+ m)
                    split_m = m.split(',')
                    for c in split_m:
                        print(c)
                        mac_count += 1
                        mac_list.append(c)
                else:
                    mac_count+=1
                    print(m)
                    mac_list.append(m)
        inFile.close()
    except Exception as e:
        print(e)
    print(f'{mac_count} mac addresses list to be traced: {mac_list}')
    return mac_list


def writeResults(result):
    '''Write final results to an output file'''
    outputFile = config['settings']['results_output']
    timeStamp = time.time()

    with open(outputFile, 'a') as output_file:
        output_file.write(f'{timeStamp}: {result}')
        output_file.close()


def trace(mac):
    ip = config['connection_params']['first_switch']
    creds = config['credentials']
    cf.close()

    connection = cisco.connectSwitch(ip, creds)
    SWITCH = ''
    PORT = ''
    first_interface = cisco.find_interfaces(mac, connection)
    first_interface_exists = cisco.checkInterface(first_interface)
    print(f'First interface exists: {first_interface_exists}')
    # Check to ensure mac returns an entry on the start switch mac table- if not, mac not found on network. Note and skip to next MAC.
    if(first_interface_exists):
        hop_found, next_hop = cisco.find_next_hop(first_interface, mac, creds, connection)
    else:
        hop_found = False 
        with open('config.yml', 'r') as file:
            conf = yaml.safe_load(file) 
        conf['output']['current_ip'] = conf['connection_params']['first_switch']
        conf['output']['current_int'] = 'None'
        with open('config.yml', 'w') as file:
            yaml.dump(conf, file)
        file.close()


    while hop_found == True:
        ip = next_hop
        connection.disconnect()
        connection = cisco.connectSwitch(ip, creds)
        interface = cisco.find_interfaces(mac, connection)
        print(f'Interface: {interface}....')
        if interface:
            if str(interface[0]) == 'None':
                hop_found = False
                break

            hop_found, next_hop = cisco.find_next_hop(interface, mac, creds, connection)
            if "Vl" in interface:
                localSwitch = ip
                localPort = interface
                hop_found = False
                break
        else:
            hop_found = False
            break

    with open('config.yml', 'r') as file:
        conf = yaml.safe_load(file)  
    
    localSwitch = conf['output']['current_ip']
    localPort = conf['output']['current_int']

    if str(localPort) == 'None':
        result = str(f'MAC {mac} was unable to be located on mac table {localSwitch}. Does not exist.\n')
        writeResults(result)
        time.sleep(2)
        connection.disconnect()
        file.close()
    else:
        logger.logAndPrint(f'MAC {mac} located at switch {localSwitch} on interface {localPort}.', 1)
        
        result = str(f'MAC: {mac} mapped to switch {localSwitch} on interface {localPort}.\n')
        writeResults(result)
        time.sleep(2)
        connection.disconnect()
        file.close()


def recursiveSearch():
    '''Search and trace each mac from mac_input.csv recursively'''
    inputList = readInputMacs()
    itemNum = 0

    for item in inputList:
        itemNum += 1
        logger.logAndPrint(f'Attempting to trace {item}... mac number {itemNum}', 1)
        trace(item)
        time.sleep(2)

def traceIP(ip):
    '''Currently in dev'''
    return

def regularSearch():
    ''' Search and trace one MAC or IP at a time using user input'''
    i = input(f'Enter IP or MAC you would like to trace (q to exit): ')
    validIP = re.match(r'^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$', i)
    validMac = re.match(r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$|^([0-9A-Fa-f]{4}\.){2}([0-9A-Fa-f]{4})$', i)

    if str(i.lower()) == 'q':
        logger.logAndPrint(f'User entered "{i}", exiting...', 1)
        return
    elif validMac:
        trace(validMac)
        regularSearch()
    elif validIP:
        traceIP(validIP)
        regularSearch()
    else:
        logger.logAndPrint(f'No valid input received for regular search.', 3)
        print(f'Valid format for macs: xx:xx:xx:xx:xx:xx, xx-xx-xx-xx-xx-xx-, xxxx.xxxx.xxxx')
        print(f'Valid format for ipv4: xxx.xxx.xxx.xxx')
        regularSearch()


def run():
    readInput = config['settings']['input_file']

    if readInput:
        recursiveSearch()
    else:
        regularSearch()
    
    sys.exit()



if __name__ == "__main__":
    run()
